var istextfile = require('./index.js');
if(istextfile('./demo.js')){
    console.log('this is a text file');
}